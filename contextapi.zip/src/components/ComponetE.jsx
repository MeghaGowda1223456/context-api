import React from 'react';
import ComponentF from './ComponentF';

function ComponetE() {
  return <div>
      <ComponentF/>
  </div>;
}

export default ComponetE;
